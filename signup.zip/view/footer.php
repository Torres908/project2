<!doctype html>
<html>
<body>
<footer class="container-fluid text-center">
    <p class="copyright" style="color:black;">
    	<a href="logout.php">Log Out</a><br>
        &copy; <?php echo date("Y"); ?> Umbrella Corporation
    </p>
</footer>
</body>
</html>