<?php include 'view/header.php'; ?>
<html>
<body>
	<div id="about" class="container-fluid">
	  <div class="row">
	    <div class="col-sm-8">
	      <h4>You are out of system!</h4>
	      <br><a href="login.php">Go back to login page</a>
	      <br>
	    </div>
	  </div>
	</div>
</body>
</html>
<?php include 'view/footer.php'; ?>