<?php include 'view/header.php'; ?>
<!doctype html>
<html>
<body>
	<div id="about" class="container-fluid">
	  <div class="row">
	    <div class="col-sm-8">
	      <h4>The email has exited!</h4>
	      <br><a href="signup_process.php"> Go back to sign up page</a>
	      <br>
	    </div>
	  </div>
	</div>
</body>
</html>
<?php include 'view/footer.php'; ?>
