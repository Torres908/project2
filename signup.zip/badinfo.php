<?php include 'view/header.php'; ?>
<!doctype html>
<html>
<body>
	<div id="about" class="container-fluid">
	  <div class="row">
	    <div class="col-sm-8">
	      <h2>Get Started</h2><br>
	      <h4>The email address doesn't exist or password is not right? Try again please!</h4>
	      <br><a href="login.php"> Go back to login page</a>
	      <br>
	    </div>
	  </div>
	</div>
</body>
</html>
<?php include 'view/footer.php'; ?>
